<?php

return [
    'ttl' => 60
];