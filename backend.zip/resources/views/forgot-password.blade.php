<p>Hi, {{ $name }}</p>
<p>Please use the below link to reset your password:</p>
<p><strong><a href="{{ $resetLink }}" target="_blank">{{ $resetLink }}</a></strong></p>
<p>
    Thank you,<br/>
    The Test Solution team
</p>