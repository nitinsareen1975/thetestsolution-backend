<div style="max-width: 767px;">
<p>Hello {{ $name }},</p>
<p>This message is a notification letting you know that you have clinical laboratory test results available.</p>
<p><a href="{{ $resultsLink }}" target="_blank">Click Here</a> to view your results.</p>
<p>
    Thank you,<br />
    The Test Solution team
</p>
</div>