<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class TestTypes extends Model
{
    protected $table = "test_types";

    protected $fillable = [];
    
    protected $hidden = [];


}
