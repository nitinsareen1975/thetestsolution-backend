<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Labs extends Model
{
    protected $table = "labs";
    
    protected $fillable = [];
    
    protected $hidden = [];


}
