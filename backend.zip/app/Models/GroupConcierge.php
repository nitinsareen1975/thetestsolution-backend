<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class GroupConcierge extends Model
{
    protected $table = "group_events";
    
    protected $fillable = [];
    
    protected $hidden = [];


}
