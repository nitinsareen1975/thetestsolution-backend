<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class TestResultTypes extends Model
{
    protected $table = "result_types";

    protected $fillable = [];
    
    protected $hidden = [];


}
