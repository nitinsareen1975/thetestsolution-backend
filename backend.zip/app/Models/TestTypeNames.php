<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class TestTypeNames extends Model
{
    protected $table = "test_type_names";

    protected $fillable = [];
    
    protected $hidden = [];


}
