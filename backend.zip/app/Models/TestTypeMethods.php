<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class TestTypeMethods extends Model
{
    protected $table = "test_type_methods";

    protected $fillable = [];
    
    protected $hidden = [];


}
