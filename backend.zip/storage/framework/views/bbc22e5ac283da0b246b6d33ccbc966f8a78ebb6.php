<style>
    table,
    table tr,
    table th,
    table td, table th {
        border: none;
        text-align: left !important;
    }
</style>
<div style="max-width: 767px;">
<p>Hello, <?php echo e($name); ?></p>
<p>You have been pre-registered for a screening.</p>
<p>We recommend that you print this email prior to coming to the testing site to make scanning easier. This will be scanned by the nurse before you are tested and will be used to track back your results.</p>
<p style="text-align: center;"><?php echo $qrCode; ?></p>
<p>Code: <?php echo e($confirmationCode); ?></p>
<p>The code is valid only for you and cannot be used by anyone else.</p>
<p>The laboratory and appointment information is as follows:</p>
<p>
<table cellspacing="0" cellpadding="0">
    <tr>
        <td>Date: </td>
        <th style="text-align: left"><?php echo e($scheduleDate); ?></th>
    </tr>
    <tr>
        <td>Time: </td>
        <th style="text-align: left"><?php echo e($scheduleTime); ?></th>
    </tr>
    <tr>
        <td>Name: </td>
        <th style="text-align: left"><?php echo e($labName); ?></th>
    </tr>
    <tr>
        <td>Address: </td>
        <th style="text-align: left"><?php echo e($labAddress); ?></th>
    </tr>
    <tr>
        <td>Map Link: </td>
        <th style="text-align: left">&nbsp;<a href="<?php echo e($mapsLink); ?>" target="_blank">Click Here</a></th>
    </tr>
</table>
</p>
<p>
    Thank you,<br />
    The Test Solution team
</p>
</div><?php /**PATH E:\prashant\personal\thetestsolution\backend\resources\views/schedule-confirmation.blade.php ENDPATH**/ ?>