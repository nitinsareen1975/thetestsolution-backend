<p>Hi, <?php echo e($name); ?></p>
<p>Please use the below link to reset your password:</p>
<p><strong><a href="<?php echo e($resetLink); ?>" target="_blank"><?php echo e($resetLink); ?></a></strong></p>
<p>
    Thank you,<br/>
    The Test Solution team
</p><?php /**PATH E:\prashant\personal\thetestsolution\backend\resources\views/forgot-password.blade.php ENDPATH**/ ?>